module.exports = {
    //enable(true) or disable(false) commands
    help: true,
    botstats: true,
    login: true,
    online: true,
    tp: true,
    command: true,
    logout: true,
    sudo: true,
    macro: true,
    stopmacro: true
}